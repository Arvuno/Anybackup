# Auth Service Manual Deployment

This guide installs the packaged chart into a Kubernetes cluster using namespace `anybackup-ai`.

## Assumptions

- Helm package: `auth-service-0.1.5.tgz`
- Namespace: `anybackup-ai`
- Release name: `auth-service`
- Keycloak image: `docker.aityp.com/image/docker.io/keycloak/keycloak:26.5.1`
- Keycloak bootstrap admin username: `admin`
- Keycloak bootstrap admin password: `Password@123`
- PostgreSQL is already deployed outside this chart.
- PostgreSQL version: `17.9`
- PostgreSQL storage: `50Gi`, expandable on an `82T` host data disk
- PostgreSQL host: `postgres.middleware`
- PostgreSQL alternate host: `postgres.middleware.svc.cluster.local`
- PostgreSQL port: `5432`
- PostgreSQL database: `keycloak`, already created and empty
- PostgreSQL user: `postgres`
- PostgreSQL password: `V9_KILL_POLICY`

This guide uses `postgres.middleware` as the default PostgreSQL host. Use `postgres.middleware.svc.cluster.local` if your cluster DNS or namespace policy requires the fully qualified service name.

## 1. Check Cluster Access

```bash
kubectl config current-context
kubectl get nodes
helm version --short
```

## 2. Prepare Package Directory

```bash
mkdir -p /opt/anybackup-ai/helm
cd /opt/anybackup-ai/helm
ls -lh auth-service-0.1.5.tgz
```

Inspect the chart package:

```bash
helm show chart ./auth-service-0.1.5.tgz
helm show values ./auth-service-0.1.5.tgz
helm lint ./auth-service-0.1.5.tgz
```

## 3. Verify PostgreSQL

The PostgreSQL instance and the `keycloak` database already exist.

Use a PostgreSQL client to verify connectivity from a network location that can reach the cluster service:

```bash
PGPASSWORD='V9_KILL_POLICY' psql \
  -h postgres.middleware \
  -p 5432 \
  -U postgres \
  -d keycloak \
  -c 'select version(), current_database(), current_user;'
```

If the short service name is not resolvable, use the fully qualified service name:

```bash
PGPASSWORD='V9_KILL_POLICY' psql \
  -h postgres.middleware.svc.cluster.local \
  -p 5432 \
  -U postgres \
  -d keycloak \
  -c 'select version(), current_database(), current_user;'
```

The expected database name is `keycloak`, and Keycloak will create its schema objects in the `public` schema unless `keycloak.database.schema` is changed.

The install values below use `postgres.middleware`. If the short service name is not resolvable from the `anybackup-ai` namespace, replace it with `postgres.middleware.svc.cluster.local`.

Optional schema permission check:

```sql
GRANT ALL ON SCHEMA public TO postgres;
```

## 4. Create Namespace

```bash
kubectl create namespace anybackup-ai
```

If the namespace already exists:

```bash
kubectl get namespace anybackup-ai
```

## 5. Create Credentials Secret

```bash
kubectl -n anybackup-ai create secret generic auth-service-keycloak-secrets \
  --from-literal=admin-password='Password@123' \
  --from-literal=database-password='V9_KILL_POLICY'
```

To replace an existing Secret:

```bash
kubectl -n anybackup-ai delete secret auth-service-keycloak-secrets

kubectl -n anybackup-ai create secret generic auth-service-keycloak-secrets \
  --from-literal=admin-password='Password@123' \
  --from-literal=database-password='V9_KILL_POLICY'
```

## 6. Create Install Values

```bash
cat > auth-service-values.yaml <<EOF
keycloak:
  replicaCount: 1

  image:
    registry: docker.aityp.com
    repository: image/docker.io/keycloak/keycloak
    tag: 26.5.1
    pullPolicy: IfNotPresent

  database:
    vendor: postgres
    host: postgres.middleware
    port: 5432
    name: keycloak
    schema: public
    username: postgres
    jdbcUrl: ""

  secrets:
    create: false
    name: auth-service-keycloak-secrets
    adminPasswordKey: admin-password
    databasePasswordKey: database-password

  bootstrapAdmin:
    username: admin

  http:
    enabled: true
    port: 8080
    managementPort: 9000
    relativePath: /api/auth_service/v1

  hostname:
    hostname: ""
    admin: ""
    strict: false
    backchannelDynamic: false

  proxy:
    headers: xforwarded

  features:
    enabled: []
    disabled:
      - admin
      - account

  health:
    enabled: true

  metrics:
    enabled: true

  service:
    type: ClusterIP
    ports:
      http: 80
      management: 9000

ingressRoute:
  enabled: true
  ingressClass: traefik
  entryPoints:
    - web
  authMiddleware:
    enabled: true
    name: api-gateway-service-api-gateway-service-auth
    namespace: api-gateway
EOF
```

## 7. Dry Run

```bash
helm upgrade --install auth-service ./auth-service-0.1.5.tgz \
  --namespace anybackup-ai \
  -f auth-service-values.yaml \
  --dry-run --debug
```

Confirm the rendered Deployment contains:

```text
image: "docker.aityp.com/image/docker.io/keycloak/keycloak:26.5.1"
KC_DB=postgres
KC_DB_URL_HOST=postgres.middleware
KC_DB_URL_DATABASE=keycloak
KC_DB_USERNAME=postgres
KC_HTTP_RELATIVE_PATH=/api/auth_service/v1
KC_FEATURES_DISABLED=admin,account
kind: IngressRoute
api-gateway/api-gateway-service-api-gateway-service-auth
```

## 8. Install

```bash
helm upgrade --install auth-service ./auth-service-0.1.5.tgz \
  --namespace anybackup-ai \
  -f auth-service-values.yaml
```

## 9. Check Deployment

```bash
helm status auth-service -n anybackup-ai
helm list -n anybackup-ai
kubectl get pods -n anybackup-ai
kubectl rollout status deployment/auth-service-auth-service -n anybackup-ai
kubectl logs -n anybackup-ai deployment/auth-service-auth-service -f
```

## 10. Verify API Access

Port-forward the internal service:

```bash
kubectl -n anybackup-ai port-forward svc/auth-service-auth-service 8080:80
```

Verify OIDC discovery:

```bash
curl -i http://127.0.0.1:8080/api/auth_service/v1/realms/master/.well-known/openid-configuration
```

Verify the token endpoint exists:

```bash
curl -i http://127.0.0.1:8080/api/auth_service/v1/realms/master/protocol/openid-connect/token
```

A `400` or `405` response from the token endpoint is acceptable for this check because no grant request body was sent. A connection failure or unexpected `404` is not acceptable.

Password reset uses native Keycloak Admin REST through the AuthService prefix:

```bash
# Recommended native email flow. Body must be ["UPDATE_PASSWORD"].
curl -i -X PUT \
  'http://127.0.0.1:8080/api/auth_service/v1/admin/realms/master/users/<user-id>/execute-actions-email?client_id=<client-id>&redirect_uri=<redirect-uri>' \
  -H 'Authorization: Bearer <admin-access-token>' \
  -H 'Content-Type: application/json' \
  -d '["UPDATE_PASSWORD"]'

# Native but deprecated by Keycloak. Prefer execute-actions-email above.
curl -i -X PUT \
  'http://127.0.0.1:8080/api/auth_service/v1/admin/realms/master/users/<user-id>/reset-password-email?client_id=<client-id>&redirect_uri=<redirect-uri>' \
  -H 'Authorization: Bearer <admin-access-token>'
```

These endpoints require Keycloak SMTP configuration to actually send email. Without SMTP, the route still reaches Keycloak but Keycloak can return an email-related error.

Verify raw Keycloak routes are not exposed on the prefixed service path:

```bash
curl -i http://127.0.0.1:8080/admin
curl -i http://127.0.0.1:8080/realms/master/protocol/openid-connect/auth
curl -i http://127.0.0.1:8080/realms/master/protocol/openid-connect/token
```

These checks should return `404`.

## 11. API Gateway Access

This chart creates Traefik `IngressRoute` rules. External access is still owned by `api_gateway_service`, which is the only component binding node-IP port 80:

```text
http://192.168.40.107/api/auth_service/v1
```

Expected available API paths through the gateway:

```bash
curl -i http://192.168.40.107/api/auth_service/v1/realms/master/.well-known/openid-configuration
curl -i http://192.168.40.107/api/auth_service/v1/realms/master/protocol/openid-connect/certs
```

Expected protected API paths through the gateway:

```bash
curl -i http://192.168.40.107/api/auth_service/v1/realms/master/protocol/openid-connect/userinfo
```

Without a valid `Authorization: Bearer ...` header this should return `401`.

Expected blocked native UI paths through the gateway:

```bash
curl -i http://192.168.40.107/api/auth_service/v1/realms/master/protocol/openid-connect/auth
curl -i http://192.168.40.107/api/auth_service/v1/resources/
```

These checks should return the Traefik gateway `404`.

## 12. Uninstall

```bash
helm uninstall auth-service -n anybackup-ai
kubectl delete secret auth-service-keycloak-secrets -n anybackup-ai
```

Only delete the namespace if no other workloads use it:

```bash
kubectl delete namespace anybackup-ai
```

## Notes

- `KC_BOOTSTRAP_ADMIN_USERNAME` and `KC_BOOTSTRAP_ADMIN_PASSWORD` initialize the admin user only when Keycloak first creates its database state.
- If the PostgreSQL database already contains initialized Keycloak data, changing the Kubernetes Secret does not reset the existing admin password.
- This deployment uses the existing PostgreSQL `keycloak` database. If other services also use this database, confirm table ownership and schema isolation before installing Keycloak into it.
- Kubernetes image references must not include `https://`; use `docker.aityp.com/image/docker.io/keycloak/keycloak:26.5.1`.
- `/api/auth_service/v1` is Keycloak's configured HTTP relative path. External path filtering is implemented by Traefik `IngressRoute` rules rather than a local proxy sidecar.
- Password reset is routed to native Keycloak Admin REST. Use `execute-actions-email` with `["UPDATE_PASSWORD"]`; `reset-password-email` is routed only for native compatibility and is deprecated by Keycloak.
