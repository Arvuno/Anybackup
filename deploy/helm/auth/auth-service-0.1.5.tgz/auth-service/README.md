# Auth Service Helm Chart

This is a local Helm chart for deploying Keycloak as the auth service. It does not depend on third-party Helm charts and does not create any PostgreSQL Kubernetes resources. Keycloak is configured to use an external PostgreSQL database as its backend storage.

The default Keycloak image is:

```text
docker.aityp.com/image/docker.io/keycloak/keycloak:26.5.1
```

The source URL form `https://docker.aityp.com/image/docker.io/keycloak/keycloak:26.5.1` is represented as a Kubernetes image reference without the `https://` scheme.

The chart also creates Traefik `IngressRoute` rules for the auth service API. Public login/bootstrap endpoints are routed without ForwardAuth, protected post-login endpoints use the global API gateway ForwardAuth middleware, and unmatched Keycloak paths are not routed externally.

## Files

- `Chart.yaml`: local chart metadata.
- `values.yaml`: Keycloak runtime, external PostgreSQL connection, and Traefik route settings.
- `templates/deployment.yaml`: Keycloak Deployment.
- `templates/ingressroute.yaml`: Traefik path rules for public, protected, and blocked-by-omission API paths.
- `templates/service.yaml`: internal HTTP and management Service. The HTTP port targets Keycloak directly.
- `templates/secret.yaml`: optional bootstrap Secret for local or test environments.

## Secrets

By default, this chart expects an existing Kubernetes Secret and does not store passwords in Git.

```bash
kubectl create namespace auth-service

kubectl -n auth-service create secret generic auth-service-keycloak-secrets \
  --from-literal=admin-password='<replace-with-admin-password>' \
  --from-literal=database-password='<replace-with-keycloak-db-password>'
```

For non-production environments, you can let this chart create the Secret:

```bash
helm upgrade --install auth-service src/helm/auth_service \
  --namespace auth-service \
  --create-namespace \
  --set keycloak.secrets.create=true \
  --set keycloak.secrets.adminPassword='<replace-with-admin-password>' \
  --set keycloak.secrets.databasePassword='<replace-with-keycloak-db-password>'
```

## External PostgreSQL

Configure the external PostgreSQL connection in `values.yaml`. This chart only passes these settings to Keycloak; it does not create PostgreSQL Deployments, StatefulSets, Services, PVCs, or Secrets beyond the optional Keycloak credential Secret.

```yaml
keycloak:
  database:
    vendor: postgres
    host: postgresql.example.internal
    port: 5432
    name: keycloak
    schema: public
    username: keycloak
    jdbcUrl: ""
```

## Install

```bash
helm upgrade --install auth-service src/helm/auth_service \
  --namespace auth-service \
  --create-namespace \
  -f src/helm/auth_service/values.yaml
```

## Traefik IngressRoute Auth And Path Blocking

Keycloak is configured to run under the AuthService contract prefix:

```text
/api/auth_service/v1
```

The chart renders Traefik `IngressRoute` rules for the externally supported paths. Public pre-login paths do not attach ForwardAuth:

- `/api/auth_service/v1/realms/{realm}/.well-known/openid-configuration`
- `/api/auth_service/v1/realms/{realm}/protocol/openid-connect/token`
- `/api/auth_service/v1/realms/{realm}/protocol/openid-connect/certs`
- `/api/auth_service/v1/realms/{realm}/protocol/openid-connect/token/introspect`

Protected post-login paths attach the API gateway ForwardAuth middleware:

- `/api/auth_service/v1/realms/{realm}/protocol/openid-connect/userinfo`
- `/api/auth_service/v1/realms/{realm}/protocol/openid-connect/logout`
- `/api/auth_service/v1/admin/realms/{realm}/users/**`
- `/api/auth_service/v1/admin/realms/{realm}/roles/{role-name}`
- `/api/auth_service/v1/admin/realms/{realm}/roles/{role-name}/users`
- `/api/auth_service/v1/admin/realms/{realm}/users/{user-id}/execute-actions-email`
- `/api/auth_service/v1/admin/realms/{realm}/users/{user-id}/reset-password-email`
- `/api/auth_service/v1/admin/realms/{realm}/users/{user-id}/reset-password`

By default the middleware reference is `api-gateway/api-gateway-service-api-gateway-service-auth`, matching the default `api_gateway_service` release name.

Blocked native Keycloak paths are implemented by omission from Traefik routing, not by an extra proxy container. Examples:

- `/`
- `/admin`
- `/admin/**`
- `/realms/{realm}/account*`
- `/realms/{realm}/login-actions/**`
- `/realms/{realm}/protocol/openid-connect/auth*`
- `/realms/{realm}/protocol/openid-connect/registrations*`
- `/realms/{realm}/protocol/openid-connect/token*`
- `/realms/{realm}/protocol/openid-connect/logout*`
- `/realms/{realm}/protocol/openid-connect/userinfo*`
- `/realms/{realm}/protocol/openid-connect/certs*`
- `/resources/**`
- `/api/auth_service/v1/realms/{realm}/protocol/openid-connect/auth*`
- `/api/auth_service/v1/realms/{realm}/login-actions/**`
- `/api/auth_service/v1/resources/**`

The default chart also sets:

```yaml
keycloak:
  features:
    disabled:
      - admin
      - account
```

Password reset uses native Keycloak Admin REST. Use `execute-actions-email` with request body `["UPDATE_PASSWORD"]` for the recommended email flow. `reset-password-email` is also proxied for native compatibility, but Keycloak marks it deprecated in favor of `execute-actions-email`. Direct custom paths such as `/api/auth_service/v1/realms/{realm}/password-reset/*` are not implemented by this chart.

External access is still owned by `api_gateway_service` because only the API gateway Traefik deployment binds the host port. This chart only defines the Traefik routes consumed by that gateway and keeps the Kubernetes Service as `ClusterIP`.

## Official Configuration Basis

- PostgreSQL backend: `KC_DB=postgres`, `KC_DB_URL_HOST`, `KC_DB_URL_PORT`, `KC_DB_URL_DATABASE`, `KC_DB_USERNAME`, `KC_DB_PASSWORD`.
- Initial admin: `KC_BOOTSTRAP_ADMIN_USERNAME`, `KC_BOOTSTRAP_ADMIN_PASSWORD`.
- HTTP and proxy: `KC_HTTP_ENABLED`, `KC_HTTP_PORT`, `KC_HTTP_RELATIVE_PATH`, `KC_PROXY_HEADERS`, `KC_HOSTNAME`, `KC_HOSTNAME_ADMIN`, `KC_HOSTNAME_STRICT`.
- Operations: `KC_HEALTH_ENABLED`, `KC_METRICS_ENABLED`.
- UI feature flags: `KC_FEATURES_DISABLED=admin,account`.
- External path auth and blocking: Traefik `IngressRoute` rules generated from `templates/ingressroute.yaml`.
